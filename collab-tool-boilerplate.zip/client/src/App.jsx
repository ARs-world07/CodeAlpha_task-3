import React, { useEffect, useState } from 'react'
import Login from './pages/Login.jsx'
import Register from './pages/Register.jsx'
import Dashboard from './pages/Dashboard.jsx'

export default function App() {
  const [route, setRoute] = useState(() => (localStorage.getItem('token') ? 'dashboard' : 'login'));
  const [user, setUser] = useState(() => JSON.parse(localStorage.getItem('user') || 'null'));

  useEffect(() => {
    const onHash = () => setRoute(window.location.hash.replace('#', '') || 'login');
    window.addEventListener('hashchange', onHash);
    onHash();
    return () => window.removeEventListener('hashchange', onHash);
  }, []);

  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setUser(null);
    setRoute('login');
    window.location.hash = '#login';
  };

  if (route === 'register') return <Register onDone={() => { window.location.hash = '#login'; }} />
  if (!localStorage.getItem('token')) return <Login onLogin={(u) => { setUser(u); window.location.hash = '#dashboard'; }} />

  return <Dashboard user={user} onLogout={logout} />
}
