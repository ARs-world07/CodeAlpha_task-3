import React, { useEffect, useState } from 'react';
import { api } from '../api';

export default function CommentList({ taskId }) {
  const [comments, setComments] = useState([]);
  const [content, setContent] = useState('');

  const load = async () => {
    const { data } = await api.get(`/comments/task/${taskId}`);
    setComments(data.comments);
  };
  useEffect(() => { load(); }, [taskId]);

  const add = async () => {
    if (!content.trim()) return;
    const { data } = await api.post('/comments', { taskId, content });
    setComments(prev => [...prev, data]);
    setContent('');
  };

  return (
    <div>
      <h4>Comments</h4>
      <div>
        {comments.map(c => (
          <div key={c.id} style={{ margin: '8px 0' }}>
            <div style={{ fontSize:12, color:'#6b7280' }}>{c.author?.name} • #{c.id}</div>
            <div>{c.content}</div>
          </div>
        ))}
      </div>
      <div className="row">
        <input className="input" placeholder="Write a comment..." value={content} onChange={e=>setContent(e.target.value)} />
        <button className="btn" onClick={add}>Send</button>
      </div>
    </div>
  );
}
