import React, { useEffect, useMemo, useState } from 'react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { api } from '../api';
import TaskModal from './TaskModal.jsx';

export default function KanbanBoard({ project }) {
  const [tasks, setTasks] = useState([]);
  const [modal, setModal] = useState(null);

  const load = async () => {
    const { data } = await api.get(`/tasks/project/${project.id}`);
    setTasks(data.tasks);
  };
  useEffect(() => { load(); }, [project.id]);

  const columns = useMemo(() => ({
    todo: { title: 'To Do', items: tasks.filter(t => t.status === 'todo') },
    inprogress: { title: 'In Progress', items: tasks.filter(t => t.status === 'inprogress') },
    done: { title: 'Done', items: tasks.filter(t => t.status === 'done') }
  }), [tasks]);

  const onDragEnd = async (result) => {
    const { destination, source, draggableId } = result;
    if (!destination) return;
    const from = source.droppableId, to = destination.droppableId;
    if (from === to) return;
    const id = Number(draggableId.replace('task_', ''));
    const task = tasks.find(t => t.id === id);
    if (!task) return;
    const { data } = await api.put(`/tasks/${id}`, { status: to });
    setTasks(prev => prev.map(t => t.id === id ? data : t));
  };

  const createQuick = async () => {
    const title = window.prompt('Task title?');
    if (!title) return;
    const { data } = await api.post('/tasks', { title, projectId: project.id, status: 'todo', priority: 'normal' });
    setTasks(prev => [data, ...prev]);
  };

  return (
    <div className="card">
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <h2>{project.name} — Board</h2>
        <button className="btn" onClick={createQuick}>+ New Task</button>
      </div>

      <DragDropContext onDragEnd={onDragEnd}>
        <div className="board">
          {Object.entries(columns).map(([key, col]) => (
            <Droppable droppableId={key} key={key}>
              {(provided) => (
                <div className="column" ref={provided.innerRef} {...provided.droppableProps}>
                  <h3>{col.title}</h3>
                  {col.items.map((task, idx) => (
                    <Draggable key={`task_${task.id}`} draggableId={`task_${task.id}`} index={idx}>
                      {(p) => (
                        <div className="task" ref={p.innerRef} {...p.draggableProps} {...p.dragHandleProps} onClick={() => setModal(task)}>
                          <strong>{task.title}</strong>
                          <div style={{ fontSize: 12, color: '#6b7280' }}>{task.priority} • #{task.id}</div>
                        </div>
                      )}
                    </Draggable>
                  ))}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          ))}
        </div>
      </DragDropContext>

      {modal && <TaskModal task={modal} onClose={() => setModal(null)} onUpdated={(t)=>{
        setTasks(prev => prev.map(x => x.id === t.id ? t : x));
      }} />}
    </div>
  );
}
