import React, { useEffect, useState } from 'react';
import { api } from '../api';
import CommentList from './CommentList.jsx';

export default function TaskModal({ task, onClose, onUpdated }) {
  const [title, setTitle] = useState(task.title);
  const [description, setDescription] = useState(task.description || '');
  const [status, setStatus] = useState(task.status);
  const [priority, setPriority] = useState(task.priority);
  const [dueDate, setDueDate] = useState(task.dueDate ? task.dueDate.slice(0,10) : '');

  const save = async () => {
    const { data } = await api.put(`/tasks/${task.id}`, { title, description, status, priority, dueDate: dueDate || null });
    onUpdated?.(data);
    onClose();
  };

  const remove = async () => {
    if (!confirm('Delete this task?')) return;
    await api.delete(`/tasks/${task.id}`);
    onUpdated?.({ ...task, deleted: true });
    onClose();
    window.location.reload();
  };

  return (
    <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,.5)', display:'flex', alignItems:'center', justifyContent:'center' }}>
      <div className="card" style={{ width: 600, maxWidth:'90vw', background:'#fff' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
          <h3>Edit Task #{task.id}</h3>
          <button className="btn secondary" onClick={onClose}>Close</button>
        </div>
        <div className="row">
          <div className="col">
            <input className="input" value={title} onChange={e=>setTitle(e.target.value)} />
            <br/>
            <textarea className="input" rows="5" placeholder="Description" value={description} onChange={e=>setDescription(e.target.value)} />
            <br/>
            <div className="row">
              <select className="input" value={status} onChange={e=>setStatus(e.target.value)}>
                <option value="todo">To Do</option>
                <option value="inprogress">In Progress</option>
                <option value="done">Done</option>
              </select>
              <select className="input" value={priority} onChange={e=>setPriority(e.target.value)}>
                <option value="low">Low</option>
                <option value="normal">Normal</option>
                <option value="high">High</option>
              </select>
              <input className="input" type="date" value={dueDate} onChange={e=>setDueDate(e.target.value)} />
            </div>
            <br/>
            <div className="row">
              <button className="btn" onClick={save}>Save</button>
              <button className="btn secondary" onClick={remove}>Delete</button>
            </div>
          </div>
        </div>
        <hr/>
        <CommentList taskId={task.id} />
      </div>
    </div>
  );
}
