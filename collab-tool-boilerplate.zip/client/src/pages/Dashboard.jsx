import React, { useEffect, useMemo, useState } from 'react';
import { api } from '../api';
import io from 'socket.io-client';
import KanbanBoard from '../components/KanbanBoard.jsx';

const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:4000';

export default function Dashboard({ user, onLogout }) {
  const [projects, setProjects] = useState([]);
  const [current, setCurrent] = useState(null);
  const [name, setName] = useState('');
  const [socket, setSocket] = useState(null);

  const loadProjects = async () => {
    const { data } = await api.get('/projects');
    setProjects(data.projects);
    if (!current && data.projects.length) setCurrent(data.projects[0]);
  };

  const createProject = async () => {
    const { data } = await api.post('/projects', { name });
    setProjects(p => [data, ...p]);
    setName('');
  };

  useEffect(() => { loadProjects(); }, []);

  useEffect(() => {
    if (!current) return;
    const s = io(API_BASE);
    s.emit('join_project', current.id);
    s.on('task_updated', () => {});
    s.on('comment_added', () => {});
    setSocket(s);
    return () => s.disconnect();
  }, [current?.id]);

  return (
    <div>
      <div className="topbar">
        <div>Welcome, {user?.name}</div>
        <div style={{ display:'flex', gap:8 }}>
          <button className="btn secondary" onClick={onLogout}>Logout</button>
        </div>
      </div>

      <div className="container">
        <div className="card" style={{ marginBottom: 12 }}>
          <h2>Your Projects</h2>
          <div className="row">
            <select className="input" value={current?.id || ''} onChange={e => setCurrent(projects.find(p => p.id == e.target.value))}>
              <option value="" disabled>Select a project</option>
              {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
            <input className="input" placeholder="New project name" value={name} onChange={e => setName(e.target.value)} />
            <button className="btn" onClick={createProject}>Create</button>
          </div>
        </div>

        {current && <KanbanBoard project={current} />}
      </div>
    </div>
  );
}
