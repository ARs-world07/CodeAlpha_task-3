import React, { useState } from 'react';
import { api } from '../api';

export default function Login({ onLogin }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [err, setErr] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    setErr('');
    try {
      const { data } = await api.post('/auth/login', { email, password });
      localStorage.setItem('token', data.token);
      localStorage.setItem('user', JSON.stringify(data.user));
      onLogin(data.user);
    } catch (e) {
      setErr(e.response?.data?.error || e.message);
    }
  };

  return (
    <div className="container">
      <h1>Sign in</h1>
      <form onSubmit={submit} className="card" style={{ maxWidth: 420 }}>
        <input className="input" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} />
        <br/>
        <input className="input" placeholder="Password" type="password" value={password} onChange={e => setPassword(e.target.value)} />
        {err && <p style={{ color: 'crimson' }}>{err}</p>}
        <br/>
        <button className="btn" type="submit">Login</button>
      </form>
      <p>New here? <a href="#register">Create an account</a></p>
    </div>
  );
}
