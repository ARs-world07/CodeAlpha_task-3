import React, { useState } from 'react';
import { api } from '../api';

export default function Register({ onDone }) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [err, setErr] = useState('');
  const [ok, setOk] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setErr('');
    try {
      await api.post('/auth/register', { name, email, password });
      setOk(true);
      onDone?.();
    } catch (e) {
      setErr(e.response?.data?.error || e.message);
    }
  };

  return (
    <div className="container">
      <h1>Create account</h1>
      <form onSubmit={submit} className="card" style={{ maxWidth: 480 }}>
        <input className="input" placeholder="Name" value={name} onChange={e => setName(e.target.value)} />
        <br/>
        <input className="input" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} />
        <br/>
        <input className="input" placeholder="Password" type="password" value={password} onChange={e => setPassword(e.target.value)} />
        {err && <p style={{ color: 'crimson' }}>{err}</p>}
        <br/>
        <button className="btn" type="submit">Register</button>
      </form>
      <p>Have an account? <a href="#login">Sign in</a></p>
      {ok && <p>Account created. Please sign in.</p>}
    </div>
  );
}
