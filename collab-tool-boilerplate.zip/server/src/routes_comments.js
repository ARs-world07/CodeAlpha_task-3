import { Router } from 'express';
import { prisma } from '../prisma.js';
import { requireAuth } from '../middleware_auth.js';

const router = Router();

router.get('/task/:taskId', requireAuth, async (req, res) => {
  const { taskId } = req.params;
  const comments = await prisma.comment.findMany({
    where: { taskId: Number(taskId) },
    include: { author: true },
    orderBy: { createdAt: 'asc' }
  });
  return res.json({ comments });
});

router.post('/', requireAuth, async (req, res) => {
  const io = req.app.get('io');
  const { taskId, content } = req.body;
  const comment = await prisma.comment.create({
    data: { taskId, content, authorId: req.user.id },
    include: { author: true }
  });

  const task = await prisma.task.findUnique({ where: { id: taskId } });
  if (task?.assigneeId) {
    await prisma.notification.create({
      data: { userId: task.assigneeId, type: 'comment_added', data: JSON.stringify({ taskId: task.id, projectId: task.projectId, commentId: comment.id }) }
    });
  }

  io.to(`project_${task.projectId}`).emit('comment_added', { comment });
  return res.json(comment);
});

export default router;
