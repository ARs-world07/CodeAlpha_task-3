import { Router } from 'express';
import { prisma } from '../prisma.js';
import { requireAuth } from '../middleware_auth.js';

const router = Router();

router.get('/', requireAuth, async (req, res) => {
  const userId = req.user.id;
  const memberships = await prisma.membership.findMany({ where: { userId }, include: { project: true } });
  const owned = await prisma.project.findMany({ where: { ownerId: userId } });
  const projects = [...owned, ...memberships.map(m => m.project)];
  return res.json({ projects });
});

router.post('/', requireAuth, async (req, res) => {
  const userId = req.user.id;
  const { name } = req.body;
  const project = await prisma.project.create({
    data: { name, ownerId: userId, memberships: { create: [{ userId, role: 'admin' }] } }
  });
  return res.json(project);
});

router.post('/:projectId/members', requireAuth, async (req, res) => {
  const userId = req.user.id;
  const { projectId } = req.params;
  const { memberEmail, role } = req.body;

  const project = await prisma.project.findUnique({ where: { id: Number(projectId) } });
  if (!project) return res.status(404).json({ error: 'Project not found' });
  if (project.ownerId !== userId) return res.status(403).json({ error: 'Only owner can add members' });

  const member = await prisma.user.findUnique({ where: { email: memberEmail } });
  if (!member) return res.status(404).json({ error: 'User not found' });

  const membership = await prisma.membership.upsert({
    where: { userId_projectId: { userId: member.id, projectId: project.id } },
    update: { role: role || 'member' },
    create: { userId: member.id, projectId: project.id, role: role || 'member' }
  });

  return res.json(membership);
});

export default router;
