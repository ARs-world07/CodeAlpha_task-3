import { Router } from 'express';
import { prisma } from '../prisma.js';
import { requireAuth } from '../middleware_auth.js';

const router = Router();

router.get('/project/:projectId', requireAuth, async (req, res) => {
  const { projectId } = req.params;
  const tasks = await prisma.task.findMany({ where: { projectId: Number(projectId) } });
  return res.json({ tasks });
});

router.post('/', requireAuth, async (req, res) => {
  const io = req.app.get('io');
  const { title, description, projectId, assigneeId, dueDate, status, priority } = req.body;
  const task = await prisma.task.create({
    data: { title, description, projectId, assigneeId, status, priority, dueDate: dueDate ? new Date(dueDate) : null }
  });

  if (assigneeId) {
    await prisma.notification.create({
      data: { userId: assigneeId, type: 'task_assigned', data: JSON.stringify({ taskId: task.id, projectId }) }
    });
  }

  io.to(`project_${projectId}`).emit('task_updated', { action: 'created', task });
  return res.json(task);
});

router.put('/:taskId', requireAuth, async (req, res) => {
  const io = req.app.get('io');
  const { taskId } = req.params;
  const { title, description, status, priority, assigneeId, dueDate } = req.body;
  const task = await prisma.task.update({
    where: { id: Number(taskId) },
    data: { title, description, status, priority, assigneeId, dueDate: dueDate ? new Date(dueDate) : null }
  });
  await prisma.notification.create({
    data: { userId: assigneeId || task.assigneeId || req.user.id, type: 'task_updated', data: JSON.stringify({ taskId: task.id, projectId: task.projectId }) }
  });
  io.to(`project_${task.projectId}`).emit('task_updated', { action: 'updated', task });
  return res.json(task);
});

router.delete('/:taskId', requireAuth, async (req, res) => {
  const io = req.app.get('io');
  const { taskId } = req.params;
  const t = await prisma.task.delete({ where: { id: Number(taskId) } });
  io.to(`project_${t.projectId}`).emit('task_updated', { action: 'deleted', taskId: t.id });
  return res.json({ ok: true });
});

export default router;
